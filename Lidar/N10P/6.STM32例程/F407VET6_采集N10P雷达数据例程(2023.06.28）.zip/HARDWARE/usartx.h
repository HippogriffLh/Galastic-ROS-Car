#ifndef __USRATX_H
#define __USRATX_H 

#include "stdio.h"
#include "sys.h"
#include "system.h"



#define HEADER_0 0xA5
#define HEADER_1 0x5A
#define Length_  0x6C

#define POINT_PER_PACK 32

typedef struct PointData
{
	uint8_t distance_h;
	uint8_t distance_l;
	uint8_t Strong;

}LidarPointStructDef;

typedef struct PackData
{
	uint8_t header_0;
	uint8_t header_1;
	uint8_t ver_len;
	
	uint8_t speed_h;
	uint8_t speed_l;
	uint8_t start_angle_h;
	uint8_t start_angle_l;	
	LidarPointStructDef point[POINT_PER_PACK];
	uint8_t end_angle_h;
	uint8_t end_angle_l;
	uint8_t crc;
}LiDARFrameTypeDef;

typedef struct PointDataProcess_
{
	u16 distance;
	float angle;
}PointDataProcessDef;


void data_task(void *pvParameters);
void data_transition(void);
void USART1_SEND(void);
void USART3_SEND(void);
void USART5_SEND(void);

void CAN_SEND(void);
void uart1_init(u32 bound);
void uart2_init(u32 bound);
void uart3_init(u32 bound);
void uart5_init(u32 bound);

int USART1_IRQHandler(void);
int USART2_IRQHandler(void);
int USART3_IRQHandler(void);
int UART5_IRQHandler(void);

void usart1_send(u8 data);
void usart5_send(u8 data);
float float_abs(float input);

void data_process(void); //���ݴ���
extern PointDataProcessDef PointDataProcess[1200] ;//����50������
extern PointDataProcessDef Dataprocess[1200];
extern LiDARFrameTypeDef Pack_Data;
extern int data_cnt,data_error_cnt;
extern int data_flag,data_process_flag;
extern float tmpnum;
#endif

